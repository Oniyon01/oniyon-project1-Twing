-- ============================================================
-- Twing 2.0 — Row Level Security (RLS) 정책
-- ============================================================
-- 보안 모델:
--   - 워커는 Service Role Key로 접근 → RLS 우회 (모든 작업 가능)
--   - 클라이언트(Expo 앱)는 Anon Key + JWT → RLS 적용
--
-- 즉 "유저가 직접 DB에 접근할 때" 어디까지 허용할지 정의.
--
-- 적용 순서:
--   1. 각 테이블에 RLS 활성화
--   2. 정책 생성
--   3. 정책 없는 작업은 자동 차단 (default deny)
-- ============================================================


-- ============================================================
-- profiles 테이블
-- ============================================================
alter table public.profiles enable row level security;

-- 누구나 프로필 조회 가능 (피드에 닉네임/등급 표시 위해)
create policy "profiles are viewable by everyone"
  on public.profiles for select
  using (true);

-- 본인만 자기 프로필 수정
create policy "users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- INSERT는 트리거로만 — 일반 클라이언트는 직접 삽입 불가
-- (에러 방지: 정책 없으면 default deny)


-- ============================================================
-- ideas 테이블
-- ============================================================
alter table public.ideas enable row level security;

-- 공유된 아이디어는 누구나 조회 / 본인 아이디어는 항상 조회
create policy "shared ideas viewable by everyone, own always viewable"
  on public.ideas for select
  using (
    is_shared = true
    or auth.uid() = user_id
  );

-- 본인만 자기 아이디어 INSERT
-- 워커가 service_role로 INSERT하므로 이 정책은 클라이언트가 직접 INSERT할 때만 적용
create policy "users can insert own ideas"
  on public.ideas for insert
  with check (auth.uid() = user_id);

-- 본인만 자기 아이디어 UPDATE
-- (잠금 해제 등은 워커가 service_role로 처리, 일반 유저가 수정할 일 거의 없음)
create policy "users can update own ideas"
  on public.ideas for update
  using (auth.uid() = user_id);

-- 본인만 자기 아이디어 DELETE
create policy "users can delete own ideas"
  on public.ideas for delete
  using (auth.uid() = user_id);


-- ============================================================
-- feedbacks 테이블
-- ============================================================
alter table public.feedbacks enable row level security;

-- 공개된 아이디어의 피드백은 누구나 조회 (집계용)
create policy "feedbacks on shared ideas viewable by everyone"
  on public.feedbacks for select
  using (
    exists (
      select 1 from public.ideas
      where ideas.id = feedbacks.idea_id
        and (ideas.is_shared = true or ideas.user_id = auth.uid())
    )
  );

-- 본인만 자기 피드백 INSERT, 본인 아이디어엔 못 함
create policy "users can insert feedback on others' shared ideas"
  on public.feedbacks for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.ideas
      where ideas.id = feedbacks.idea_id
        and ideas.is_shared = true
        and ideas.user_id != auth.uid()  -- 본인 아이디어에 본인이 피드백 금지
    )
  );

-- 본인 피드백만 UPDATE (의향 변경 가능)
create policy "users can update own feedback"
  on public.feedbacks for update
  using (auth.uid() = user_id);

-- 본인 피드백 삭제 가능
create policy "users can delete own feedback"
  on public.feedbacks for delete
  using (auth.uid() = user_id);


-- ============================================================
-- comments 테이블
-- ============================================================
alter table public.comments enable row level security;

-- 공유 아이디어의 댓글은 누구나 조회
create policy "comments on shared ideas viewable by everyone"
  on public.comments for select
  using (
    exists (
      select 1 from public.ideas
      where ideas.id = comments.idea_id
        and (ideas.is_shared = true or ideas.user_id = auth.uid())
    )
  );

-- 공유 아이디어에만 댓글 작성 가능 (자기 아이디어 포함)
create policy "users can comment on shared ideas"
  on public.comments for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.ideas
      where ideas.id = comments.idea_id
        and ideas.is_shared = true
    )
  );

-- 본인 댓글만 수정/삭제
create policy "users can update own comments"
  on public.comments for update
  using (auth.uid() = user_id);

create policy "users can delete own comments"
  on public.comments for delete
  using (auth.uid() = user_id);


-- ============================================================
-- likes 테이블
-- ============================================================
alter table public.likes enable row level security;

-- 좋아요는 누구나 조회 (카운트용)
create policy "likes viewable by everyone"
  on public.likes for select
  using (true);

-- 공유 아이디어에만 좋아요 가능
create policy "users can like shared ideas"
  on public.likes for insert
  with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.ideas
      where ideas.id = likes.idea_id
        and ideas.is_shared = true
    )
  );

-- 좋아요 해제(delete) 가능
create policy "users can unlike own"
  on public.likes for delete
  using (auth.uid() = user_id);


-- ============================================================
-- 검증 — 정책 확인 SQL
-- ============================================================
-- 운영 시 이 쿼리로 RLS 적용 상태 확인:
--
-- select schemaname, tablename, rowsecurity
-- from pg_tables
-- where schemaname = 'public';
--
-- select * from pg_policies where schemaname = 'public';
