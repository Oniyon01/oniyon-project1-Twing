-- ============================================================
-- Twing 2.0 — 핫점수 계산 + 헬퍼 함수
-- ============================================================
-- PRD 8.1 핫점수 공식을 SQL 함수로 구현.
-- 클라이언트가 RPC로 호출하거나, 워커가 백그라운드 작업으로 호출.
--
-- 비고: 이 계산을 매번 실시간으로 하면 부하 큼.
-- 운영 시엔 cron으로 1시간마다 일괄 갱신 권장.
-- ============================================================


-- ============================================================
-- 1. 단일 아이디어의 핫점수 계산
-- ============================================================
create or replace function public.calculate_hot_score(idea_id_param uuid)
returns numeric
language plpgsql
stable  -- 같은 입력엔 같은 결과 (단, 내부에서 now()를 쓰니 시간 의존)
as $$
declare
  v_likes int;
  v_feedbacks int;
  v_try_votes int;
  v_hours_ago numeric;
  v_score numeric;
begin
  -- 좋아요 수
  select count(*) into v_likes
  from public.likes
  where idea_id = idea_id_param;

  -- 피드백 수
  select count(*) into v_feedbacks
  from public.feedbacks
  where idea_id = idea_id_param;

  -- "직접 해볼래" 투표 수
  select count(*) into v_try_votes
  from public.feedbacks
  where idea_id = idea_id_param
    and participation = 'try';

  -- 경과 시간 (시간 단위)
  select extract(epoch from (now() - created_at)) / 3600
  into v_hours_ago
  from public.ideas
  where id = idea_id_param;

  if v_hours_ago is null then
    return 0;
  end if;

  -- 핫점수 공식: (좋아요×2 + 피드백×3 + try×5) / (시간+2)^2
  v_score := (v_likes * 2 + v_feedbacks * 3 + v_try_votes * 5)::numeric
             / power(v_hours_ago + 2, 2);

  return round(v_score, 2);
end;
$$;

comment on function public.calculate_hot_score is 'PRD 8.1 핫점수 계산. (좋아요×2 + 피드백×3 + try×5) / (시간h+2)^2';


-- ============================================================
-- 2. 모든 공유 아이디어의 핫점수 일괄 갱신
-- ============================================================
-- cron으로 주기 호출:
--   1시간마다 → select public.refresh_hot_scores();
create or replace function public.refresh_hot_scores()
returns int
language plpgsql
as $$
declare
  v_updated_count int;
begin
  with updated as (
    update public.ideas
    set hot_score = public.calculate_hot_score(id)
    where is_shared = true
      and created_at > now() - interval '7 days'  -- 7일 이내 것만 갱신 (오래된 건 hot에서 자연 탈락)
    returning id
  )
  select count(*) into v_updated_count from updated;

  return v_updated_count;
end;
$$;

comment on function public.refresh_hot_scores is '공유된 아이디어 핫점수 일괄 갱신. 7일 이내 것만 대상. cron으로 1시간마다 호출 권장.';


-- ============================================================
-- 3. 포인트 지급 헬퍼 함수
-- ============================================================
-- 활동에 따라 profiles.points를 증가. 동시에 등급 자동 갱신.
-- 등급 임계값: 트린이=0, 윙눈이=300, 윙이어=1200, 윙터치=4000, 골드윙=10000, 트윙글=30000
create or replace function public.add_points(
  user_id_param uuid,
  amount int,
  reason text default null
)
returns int
language plpgsql
as $$
declare
  v_new_points int;
  v_new_level int;
begin
  -- 포인트 추가
  update public.profiles
  set points = points + amount
  where id = user_id_param
  returning points into v_new_points;

  if v_new_points is null then
    raise exception 'profile not found: %', user_id_param;
  end if;

  -- 등급 재계산
  v_new_level := case
    when v_new_points >= 30000 then 6  -- 트윙글
    when v_new_points >= 10000 then 5  -- 골드윙
    when v_new_points >= 4000  then 4  -- 윙터치
    when v_new_points >= 1200  then 3  -- 윙이어
    when v_new_points >= 300   then 2  -- 윙눈이
    else 1                              -- 트린이
  end;

  update public.profiles
  set level = v_new_level
  where id = user_id_param;

  -- TODO: 운영 시 별도 'point_transactions' 테이블에 reason과 함께 기록 권장

  return v_new_points;
end;
$$;

comment on function public.add_points is '포인트 지급 + 등급 자동 갱신. 워커나 트리거에서 호출.';


-- ============================================================
-- 4. 첫 아이디어 등록 시 onboarding 완료 + 보너스 포인트
-- ============================================================
-- ideas INSERT 트리거로 자동 처리
create or replace function public.handle_first_idea()
returns trigger
language plpgsql
as $$
declare
  v_already_completed boolean;
begin
  select has_completed_onboarding into v_already_completed
  from public.profiles
  where id = new.user_id;

  -- 첫 아이디어 등록이면
  if v_already_completed = false then
    update public.profiles
    set has_completed_onboarding = true
    where id = new.user_id;

    -- +20pt 보너스 (랭킹 문서의 "첫 아이디어 등록 +20" 그대로)
    perform public.add_points(new.user_id, 20, 'first_idea_bonus');
  end if;

  -- 일반 등록 +10pt
  perform public.add_points(new.user_id, 10, 'idea_post');

  return new;
end;
$$;

create trigger on_idea_inserted
  after insert on public.ideas
  for each row execute function public.handle_first_idea();
