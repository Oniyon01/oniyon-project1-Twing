# 🗄️ Twing Supabase 스키마

Twing 2.0의 데이터베이스 스키마. 5개 테이블 + RLS 정책 + 헬퍼 함수.

## 📦 무엇이 들어있나

| 파일 | 적용 순서 | 역할 |
|---|---|---|
| `00_test_mock_auth.sql` | (테스트만) | 로컬 PostgreSQL에서 auth 스키마 모킹. **운영 환경에선 절대 실행하지 마세요** |
| `01_schema.sql` | 1️⃣ | 5개 테이블, 인덱스, updated_at 트리거, 신규 유저 트리거 |
| `02_rls.sql` | 2️⃣ | Row Level Security 정책 (클라이언트용) |
| `03_functions.sql` | 3️⃣ | 핫점수 계산, 포인트 지급, 등급 갱신, 첫 아이디어 보너스 |
| `04_seed.sql` | 4️⃣ (선택) | 윙글이 공식 시드 계정 + 시딩 카드 (운영 시작 전 1회) |

## 🏗️ 구조 한눈에

```
auth.users (Supabase 관리)
   ↓ on_auth_user_created 트리거
public.profiles (닉네임, 등급, 포인트)
   ↓ user_id FK
public.ideas (variants, deep_analysis, category)
   ├─ public.feedbacks (참여 의향, 추가 제안)
   ├─ public.comments (자유 댓글)
   └─ public.likes (좋아요)
```

## 🚀 운영 환경 적용 (Supabase)

### 1. Supabase 프로젝트 준비
- https://supabase.com 에서 새 프로젝트 생성
- Authentication 활성화 확인 (기본 활성화)

### 2. SQL 적용
대시보드 > SQL Editor 열고 **순서대로** 실행:

```sql
-- ⚠️ 00_test_mock_auth.sql 은 건너뛰세요 (Supabase는 auth가 이미 있음)

-- 1️⃣ 01_schema.sql 전체 복붙 → Run
-- 2️⃣ 02_rls.sql 전체 복붙 → Run
-- 3️⃣ 03_functions.sql 전체 복붙 → Run
```

### 3. 워커 환경 변수 설정
```bash
cd twing-workers
wrangler secret put SUPABASE_SERVICE_KEY
# 값: Supabase 대시보드 > Settings > API > service_role key
```

### 4. 시딩 카드 추가 (선택)
- Supabase Auth UI에서 `wingle@twing.app` 같은 윙글이 이메일로 가입
- `04_seed.sql` 열고 `:wingle_user_id` 자리에 그 유저 UUID 박기
- 주석 해제 후 SQL Editor에서 Run

### 5. 핫점수 자동 갱신 (선택)
Supabase 대시보드 > Database > Cron 으로 1시간마다 호출:
```sql
select public.refresh_hot_scores();
```
또는 `pg_cron` 확장 활성화 후:
```sql
select cron.schedule('refresh-hot-scores', '0 * * * *', 'select public.refresh_hot_scores();');
```

## 🧪 로컬 검증 (선택)

PostgreSQL 14+ 가 있다면 로컬에서도 검증 가능:

```bash
createdb twing_test
psql -d twing_test -f 00_test_mock_auth.sql  # auth 스키마 모킹
psql -d twing_test -f 01_schema.sql
psql -d twing_test -f 02_rls.sql
psql -d twing_test -f 03_functions.sql
```

이 패키지는 PostgreSQL 16에서 13개 종단 테스트(트리거, CHECK 제약, RLS, 외래키, 핫점수 계산, 등급 자동 갱신)를 모두 통과했습니다.

## 🔑 핵심 설계 결정

### 1. profiles 분리 (auth.users 1:1)
Supabase Auth의 `auth.users`는 비밀번호/JWT만. 닉네임/등급/포인트는 `public.profiles`에. 신규 가입 시 `on_auth_user_created` 트리거로 자동 생성.

### 2. 카테고리 enum 강제 (CHECK 제약)
워커 검증을 거쳐도 DB에서 한 번 더 막음. 카테고리 추가/제거 시 SQL 마이그레이션 필요하지만, 자주 바뀌지 않으니 OK.

### 3. RLS 정책 = 클라이언트 직접 접근용
**워커는 Service Role Key로 RLS 우회**. RLS는 Expo 앱이 Supabase에 직접 접근할 때만 적용.
- 공유 아이디어는 누구나 조회
- 본인 아이디어는 항상 조회
- 본인 아이디어엔 본인 피드백 금지 (어뷰징 방지)

### 4. 핫점수 = 함수로 분리
PRD 8.1 공식 `(좋아요×2 + 피드백×3 + try×5) / (시간h+2)^2`을 `calculate_hot_score()` 함수에. 매번 실시간 계산은 부하 크니 `refresh_hot_scores()`로 cron 갱신.

### 5. 등급 자동 갱신
`add_points()` 함수가 포인트 추가하면서 임계값(0/300/1200/4000/10000/30000) 자동 체크해서 `level` 갱신. 트린이→윙눈이→윙이어→윙터치→골드윙→트윙글.

### 6. 첫 아이디어 보너스 트리거
`handle_first_idea` 트리거가 INSERT 시점에 `has_completed_onboarding`을 체크하고:
- 첫 등록이면 +20pt + onboarding 완료 표시
- 두 번째부터는 +10pt만

빈 피드 환영 카드는 `has_completed_onboarding = false`인 유저에게만 노출.

## 📊 인덱스 전략

| 인덱스 | 목적 |
|---|---|
| `ideas_created_at_idx` | 피드 최신순 정렬 |
| `ideas_hot_score_idx (where is_shared)` | 인기순 정렬 (부분 인덱스로 크기 ↓) |
| `ideas_category_idx (where is_shared)` | 카테고리 필터 |
| `ideas_user_id_idx` | 마이페이지 본인 아이디어 |
| `ideas_wingle_pick_idx (where is_pick)` | 윙글이 픽 페이지 |
| `feedbacks_idea_id_idx` | 카드 집계 |
| `profiles_level_points_idx` | 유저 랭킹 |

부분 인덱스(`where ...`)를 적극 활용해서 인덱스 크기를 줄였어요.

## 🛡️ 운영 시 추가 권장사항

1. **백업** — Supabase Pro 플랜은 자동 백업. Free는 수동 dump 필요
2. **모니터링** — Supabase 대시보드 > Reports > Slow queries 확인
3. **포인트 트랜잭션 로그** — 추후 `point_transactions` 테이블 추가해서 어뷰징 추적
4. **신고 시스템** — `reports` 테이블 추가 (PRD 어뷰징 방지)
5. **카테고리 추가** — `01_schema.sql`의 CHECK 제약 + 워커 `categories.js` 동시 수정

## 🔗 관련 문서

- 프롬프트 v1.1: `twing_prompts_final_v1.1.md`
- 워커 v1.1: `twing-workers-v1.1.tar.gz`
- PRD 13장 (데이터 구조): `Twing_2_0_PRD.md`
- 랭킹 시스템: `twing_ranking_system.md`
