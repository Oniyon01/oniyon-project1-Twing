-- ============================================================
-- Twing 2.0 — 시딩 데이터 (선택, 운영 시작 전 1회만)
-- ============================================================
-- 빈 피드 상태 A 화면에서 보여줄 윙글이 공식 계정 + 시딩 카드 1-2개.
-- PRD 7.3 시딩 전략 ("론칭 전 시딩 콘텐츠 20-30개")의 시작.
--
-- 주의:
--   - 이 SQL은 auth.users에 윙글이 계정을 직접 만들지 않음.
--   - 어드민이 Supabase 대시보드에서 윙글이 이메일로 가입 후,
--     생성된 user.id를 가져와 아래 빈칸에 박아넣은 다음 실행.
-- ============================================================

-- ============================================================
-- 1. 윙글이 공식 계정을 시드 계정으로 표시
-- ============================================================
-- 사용 전 :wingle_user_id 자리에 실제 UUID 박을 것

/*
update public.profiles
set
  nickname = '윙글이',
  level = 6,                         -- 트윙글 (최상위)
  points = 99999,
  is_seed_account = true,
  has_completed_onboarding = true
where id = ':wingle_user_id'::uuid;  -- ← 실제 UUID로 교체
*/


-- ============================================================
-- 2. 시딩 카드 1번 — "화분에 이름 붙이기" (펫 카테고리)
-- ============================================================
-- 빈 상태 와이어프레임에서 사용한 예시 그대로

/*
insert into public.ideas (
  user_id,
  core_idea,
  emotion_tone,
  participation,
  differentiator,
  category,
  detected_flavor,
  inferred_differentiator,
  variants,
  is_shared,
  selected_variant_index,
  shared_at
)
values (
  ':wingle_user_id'::uuid,
  '화분에 이름 붙이기',
  '공감',
  '관전형',
  '식물도 친구가 되는 관계',
  '펫',
  '#식물도친구 × 솔로 라이프 × 의인화 콘텐츠',
  '식물도 친구가 되는 관계',
  '[
    {
      "angle": "이름의 의례",
      "challenge_name": "내화분이름은",
      "hashtags": ["#내화분이름은", "#식물도친구", "#반려식물일기"],
      "wingle_comment": "내 화분 이름은 윙초야. 안 부르면 시들어 🥹",
      "caption_hook": "아침에 일어나서 화분에 인사하는 5초 클로즈업",
      "variation_seed": "매회 새로 들인 식물 등장"
    },
    {
      "angle": "식물 관계도",
      "challenge_name": "식물가계도",
      "hashtags": ["#식물가계도", "#반려식물네트워크", "#윙초의친척"],
      "wingle_comment": "윙초의 사촌 윙치도 데려왔어 🌱",
      "caption_hook": "포트폴리오 슬라이드처럼 식물 관계도 그리기",
      "variation_seed": "매회 식물 가족 추가"
    },
    {
      "angle": "성장 일기",
      "challenge_name": "식물성장로그",
      "hashtags": ["#식물성장로그", "#그린루틴", "#윙초의100일"],
      "wingle_comment": "100일 키운 윙초가 꽃을 피웠어 🌸",
      "caption_hook": "타임랩스로 성장 과정 압축",
      "variation_seed": "회차별 다른 시기 기록"
    }
  ]'::jsonb,
  true,
  0,
  now() - interval '3 days'
);
*/


-- ============================================================
-- 사용 방법
-- ============================================================
-- 1. Supabase Auth로 윙글이 이메일 (예: wingle@twing.app) 가입
-- 2. SQL Editor에서 select id from auth.users where email='wingle@twing.app';
-- 3. 위 ":wingle_user_id" 자리에 그 UUID 박아넣고 주석 해제 후 실행
-- 4. 시딩 카드 추가하고 싶을 때마다 INSERT 블록 복제해서 카드 정보 채우기
