-- ============================================================
-- Twing 2.0 — Supabase 스키마 마이그레이션 v1.0
-- ============================================================
-- 적용 방법:
--   1. Supabase 대시보드 > SQL Editor 에서 이 파일 전체 실행
--   2. 또는 supabase CLI: `supabase db push`
--
-- 의존성:
--   - Supabase Auth가 활성화되어 있어야 함 (auth.users 테이블 존재)
--
-- 주요 테이블:
--   profiles    — 유저 프로필 (닉네임, 등급, 포인트)
--   ideas       — 트렌드 아이디어 (variants, deep_analysis 포함)
--   feedbacks   — 구조화 피드백 (참여 의향, 추가 제안, 플랫폼 추천)
--   comments    — 자유 댓글
--   likes       — 좋아요
-- ============================================================

-- ============================================================
-- 0. 확장 활성화
-- ============================================================
-- gen_random_uuid()를 쓰기 위해 pgcrypto 활성화
-- (Supabase는 기본으로 활성화되어 있지만 명시적으로 한 번 더)
create extension if not exists "pgcrypto";


-- ============================================================
-- 1. profiles 테이블
-- ============================================================
-- auth.users의 id를 1:1로 참조하는 우리 앱 전용 프로필
-- 새 유저 가입 시 트리거로 자동 생성됨 (아래 5번 섹션 참조)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,

  -- 표시 정보
  nickname varchar(20) not null,
  avatar_url text,

  -- 등급 시스템 (랭킹 문서의 6단계: 트린이→윙눈이→윙이어→윙터치→골드윙→트윙글)
  level int not null default 1 check (level between 1 and 6),
  points int not null default 0 check (points >= 0),

  -- 운영 플래그
  has_completed_onboarding boolean not null default false,
  is_seed_account boolean not null default false,

  -- 타임스탬프
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 닉네임 검색용
create index profiles_nickname_idx on public.profiles (nickname);

-- 등급별 랭킹 조회용 (랭킹 화면에서 트윙글 등급 유저만 보고 싶다거나)
create index profiles_level_points_idx on public.profiles (level desc, points desc);

comment on table public.profiles is '앱 유저 프로필. auth.users와 1:1 매핑.';
comment on column public.profiles.is_seed_account is '윙글이 공식 계정 등 시딩 콘텐츠 작성용 플래그. true면 카드에 "시딩" 라벨 표시.';
comment on column public.profiles.has_completed_onboarding is '첫 아이디어 등록 완료 시 true. 빈 피드 환영 카드 표시 여부 결정.';


-- ============================================================
-- 2. ideas 테이블
-- ============================================================
-- 메인 콘텐츠. 워커의 generate-variants와 deep-analysis가 모두 이 테이블에 씀.
create table public.ideas (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,

  -- 유저 입력 (재호출 위해 보존)
  core_idea text not null check (length(core_idea) between 2 and 200),
  emotion_tone varchar(10) not null check (emotion_tone in ('웃김','멋짐','공감','충격','호기심')),
  participation varchar(10) not null check (participation in ('챌린지','도전형','관전형')),
  differentiator text,
  reference text,

  -- AI 분류 결과 (Prompt A의 카테고리)
  category varchar(10) not null check (category in (
    '갓생','힐링','컬처','일상','푸드','스타일','테크','펫','게임','유머'
  )),

  -- AI 응답 — Prompt A
  detected_flavor text not null,
  inferred_differentiator text not null,
  variants jsonb not null,  -- variants 배열 (3개)

  -- 잠금 해제 상태
  is_shared boolean not null default false,
  selected_variant_index int check (selected_variant_index between 0 and 2),
  deep_analysis jsonb,  -- Prompt B 응답 (잠금 해제 후만 채워짐)
  shared_at timestamptz,

  -- 랭킹용
  hot_score numeric(10, 2) not null default 0,
  is_wingle_pick boolean not null default false,

  -- 타임스탬프
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 피드 정렬용 (최신순)
create index ideas_created_at_idx on public.ideas (created_at desc);

-- 인기순 정렬용
create index ideas_hot_score_idx on public.ideas (hot_score desc) where is_shared = true;

-- 카테고리 필터용
create index ideas_category_idx on public.ideas (category) where is_shared = true;

-- 마이페이지에서 본인 아이디어 조회용
create index ideas_user_id_idx on public.ideas (user_id, created_at desc);

-- 윙글이 픽 조회용
create index ideas_wingle_pick_idx on public.ideas (is_wingle_pick, created_at desc) where is_wingle_pick = true;

comment on table public.ideas is '유저의 트렌드 아이디어. 워커가 AI 응답으로 채움.';
comment on column public.ideas.variants is 'Prompt A의 variants 배열. JSON 구조: [{angle, challenge_name, hashtags, wingle_comment, caption_hook, variation_seed}, ...]';
comment on column public.ideas.deep_analysis is 'Prompt B 응답 전체. is_shared=true일 때만 채워짐.';
comment on column public.ideas.hot_score is 'PRD 8.1 핫점수 공식: (좋아요×2 + 피드백수×3 + try투표×5) / (시간h+2)^2';


-- ============================================================
-- 3. feedbacks 테이블 (구조화 피드백)
-- ============================================================
create table public.feedbacks (
  id uuid primary key default gen_random_uuid(),
  idea_id uuid not null references public.ideas(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,

  -- 참여 의향 — 핫점수 가중치 ×5의 핵심 신호
  participation varchar(10) not null check (participation in ('try','watch','unsure')),

  -- 추가 제안 (선택)
  suggestion text check (length(suggestion) <= 200),

  -- 추천 플랫폼 (선택)
  platform_vote varchar(20) check (platform_vote in ('tiktok','instagram','youtube_shorts')),

  created_at timestamptz not null default now(),

  -- 한 유저가 같은 아이디어에 한 번만 피드백 (수정은 update로)
  unique (idea_id, user_id)
);

-- 본인의 피드백 이력 조회용
create index feedbacks_user_id_idx on public.feedbacks (user_id, created_at desc);

-- 아이디어별 피드백 집계용
create index feedbacks_idea_id_idx on public.feedbacks (idea_id);

comment on table public.feedbacks is 'PRD 7.2 구조화 피드백. 한 유저가 한 아이디어에 1개만 가능 (UNIQUE).';
comment on column public.feedbacks.participation is 'try=직접 해볼래(가중치 ×5), watch=구경할래(×1), unsure=글쎄(×0)';


-- ============================================================
-- 4. comments 테이블 (자유 댓글)
-- ============================================================
create table public.comments (
  id uuid primary key default gen_random_uuid(),
  idea_id uuid not null references public.ideas(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,

  content text not null check (length(content) between 1 and 500),

  created_at timestamptz not null default now()
);

create index comments_idea_id_idx on public.comments (idea_id, created_at desc);
create index comments_user_id_idx on public.comments (user_id, created_at desc);

comment on table public.comments is '자유 댓글. 한 유저가 같은 아이디어에 여러 개 가능.';


-- ============================================================
-- 5. likes 테이블 (좋아요)
-- ============================================================
-- 새 카드 디자인에서 좋아요는 카드 표면에서 제거됐지만,
-- 더보기 메뉴의 "🔖 나중에 보기" 같은 형태로 남을 수 있음.
-- 또한 핫점수 공식에서 ×2 가중치로 사용됨.
create table public.likes (
  id uuid primary key default gen_random_uuid(),
  idea_id uuid not null references public.ideas(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,

  created_at timestamptz not null default now(),

  -- 한 유저가 같은 아이디어에 좋아요 1번만
  unique (idea_id, user_id)
);

create index likes_idea_id_idx on public.likes (idea_id);
create index likes_user_id_idx on public.likes (user_id, created_at desc);


-- ============================================================
-- 6. updated_at 자동 갱신 트리거
-- ============================================================
-- ideas, profiles 테이블의 updated_at을 업데이트 시 자동 갱신
create or replace function public.handle_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.handle_updated_at();

create trigger ideas_updated_at
  before update on public.ideas
  for each row execute function public.handle_updated_at();


-- ============================================================
-- 7. auth.users → profiles 자동 생성 트리거
-- ============================================================
-- 새 유저가 Supabase Auth로 가입하면 profiles 행도 자동 생성.
-- nickname은 이메일 앞부분으로 임시 생성, 나중에 유저가 수정.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer  -- auth.users 트리거에서 실행되려면 이 권한 필요
set search_path = public
as $$
begin
  insert into public.profiles (id, nickname)
  values (
    new.id,
    -- 이메일 @ 앞부분 + 4자리 랜덤 (중복 방지)
    coalesce(
      split_part(new.email, '@', 1),
      'twinger'
    ) || '_' || substring(replace(new.id::text, '-', ''), 1, 4)
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();
