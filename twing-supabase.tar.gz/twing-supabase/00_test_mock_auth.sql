-- ============================================================
-- 테스트 환경에서만 — Supabase auth 스키마 모킹
-- ============================================================
-- Supabase에선 auth.users가 자동 생성되지만,
-- 로컬 PostgreSQL에선 직접 만들어줘야 함.
-- 이 파일은 검증용이고 운영에는 사용 X.

create schema if not exists auth;

create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text unique
);

-- Supabase의 auth.uid() 함수 모킹 (테스트용)
create or replace function auth.uid()
returns uuid
language sql
stable
as $$
  -- 테스트에서는 항상 첫 번째 유저로 처리
  select id from auth.users limit 1;
$$;
